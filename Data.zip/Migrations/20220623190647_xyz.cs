﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CatalogoProdutos.Migrations
{
    public partial class xyz : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
